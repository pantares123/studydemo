package com.zch.graduationdesign.entity;

import lombok.Data;

@Data
public class testEntity {
    private String id;
    private String subject;
}
