package com.zch.graduationdesign;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication

public class GraduationdesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(GraduationdesignApplication.class, args);
    }

}
