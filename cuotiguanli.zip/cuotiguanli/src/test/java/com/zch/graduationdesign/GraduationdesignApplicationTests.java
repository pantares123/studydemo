package com.zch.graduationdesign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GraduationdesignApplicationTests {

    @Test
    void contextLoads() {
    }

}
